Get browscap.ini here:
http://tempdownloads.browserscap.com/
